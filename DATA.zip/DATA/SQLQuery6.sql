select * from [dbo].[Currency_Rates]

slect