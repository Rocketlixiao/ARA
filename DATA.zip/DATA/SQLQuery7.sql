select * from pyramid
where idAccount = 0

where [Pyramid Asset Code] in ('R0P2226976411','R0P2226963871','R0P2226963869')



select * from [dbo].[Account_regions]
where [Pyramid Schedule Number] = 'GMS002CTX000005US-01'


select * from [dbo].[Mark_for_report]
USB646300J-11

USB646300J-12


